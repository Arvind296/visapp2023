import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfound-layout',
  templateUrl: './notfound-layout.component.html',
  styleUrls: ['./notfound-layout.component.css']
})
export class NotFoundLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}